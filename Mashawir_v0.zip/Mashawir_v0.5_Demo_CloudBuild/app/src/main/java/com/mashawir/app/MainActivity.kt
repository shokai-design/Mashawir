package com.mashawir.app

import android.content.Intent
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 60, 40, 60)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "مشاوير"
            textSize = 38f
            setTextColor(Color.rgb(20,20,20))
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "مشوارك أسهل وأسرع\nولاية كسلا"
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 50)
        }

        val button = Button(this).apply {
            text = "ابدأ الآن"
            textSize = 18f
            setOnClickListener {
                startActivity(Intent(this@MainActivity, RideMapActivity::class.java))
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(button, LinearLayout.LayoutParams(-1, 60))
        setContentView(root)
    }
}
