package com.mashawir.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class RideMapActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private val kassala = GeoPoint(15.45, 36.40)
    private val locationClient by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private var marker: Marker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().userAgentValue = packageName

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val header = TextView(this).apply {
            text = "مشاوير • كسلا"
            textSize = 22f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(20,20,20))
            gravity = Gravity.CENTER
            setPadding(10, 20, 10, 20)
        }

        map = MapView(this).apply {
            setMultiTouchControls(true)
            controller.setZoom(13.0)
            controller.setCenter(kassala)
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
        }

        val locationBtn = Button(this).apply {
            text = "موقعي"
            setOnClickListener { locateMe() }
        }

        val carBtn = Button(this).apply {
            text = "🚗 سيارة"
            setOnClickListener { showFare("سيارة") }
        }

        val motoBtn = Button(this).apply {
            text = "🏍️ موتر"
            setOnClickListener { showFare("موتر") }
        }

        controls.addView(locationBtn, LinearLayout.LayoutParams(0, 60, 1f))
        controls.addView(carBtn, LinearLayout.LayoutParams(0, 60, 1f))
        controls.addView(motoBtn, LinearLayout.LayoutParams(0, 60, 1f))

        root.addView(header)
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(controls)

        setContentView(root)
    }

    private fun locateMe() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                100
            )
            return
        }

        locationClient.lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                val p = GeoPoint(loc.latitude, loc.longitude)
                map.controller.animateTo(p)
                map.controller.setZoom(16.0)

                marker?.let { map.overlays.remove(it) }
                marker = Marker(map).apply {
                    position = p
                    title = "موقعك"
                    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                }
                map.overlays.add(marker)
                map.invalidate()
            }
        }
    }

    private fun showFare(type: String) {
        val fare = if (type == "سيارة") 1500 else 1000
        android.widget.Toast.makeText(
            this,
            "$type • أجرة تجريبية تبدأ من $fare جنيه سوداني",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }
}
